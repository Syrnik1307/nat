export { default as HomeworkConstructor } from './components/homework/HomeworkConstructor';
