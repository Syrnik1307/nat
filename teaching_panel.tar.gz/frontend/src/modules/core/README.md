# 🎓 Модуль Core + Zoom + Schedule

**Ответственный:** Ты  
**Детальное ТЗ:** [`../../CORE_MODULE_SPEC.md`](../../CORE_MODULE_SPEC.md)

## 🎯 Назначение
Фундамент платформы: авторизация, группы, расписание, Zoom Pool, посещаемость, дашборды.

## 📁 Структура папок
```
core/
├── auth/
│   ├── LoginPage.js          ✅ Есть
│   ├── RegisterPage.js       🆕 Создать
│   └── authService.js
├── groups/
│   ├── GroupsManage.js       ✅ Готово
│   └── groupsService.js
├── schedule/
│   ├── RecurringLessons.js   ✅ Есть
│   ├── Calendar.js           🆕 Создать
│   └── scheduleService.js
├── zoom/
│   ├── ZoomPoolManager.js    🆕 Создать
│   ├── StartLessonButton.js  🆕 Создать
│   └── zoomService.js        🆕 Создать
├── attendance/
│   ├── LessonAttendance.js   ✅ Есть
│   └── attendanceService.js
└── navigation/
    ├── NavBar.js             ✅ Готово
    ├── HomePage.js           ✅ Готово
    ├── TeacherDashboard.js   ✅ Есть
    └── StudentDashboard.js   ✅ Есть
```

## 🔗 API Endpoints (уже есть)
- `/api/jwt/token/` - login
- `/api/groups/` - группы
- `/api/recurring-lessons/` - расписание
- `/api/attendance/` - посещаемость

## 🆕 Новые endpoints (нужно создать)
- `/api/zoom-accounts/` - управление Zoom
- `/api/students/bulk-import/` - импорт студентов
- `/api/notifications/counts/` - счетчики

## 🚀 Старт разработки
См. подробные промпты в [`CORE_MODULE_SPEC.md`](../../CORE_MODULE_SPEC.md)

## ✅ Чеклист
- [ ] Авторизация (улучшить)
- [x] Группы (✅ готово)
- [ ] Календарь
- [ ] Zoom Pool
- [x] Расписание (✅ частично)
- [ ] Посещаемость (улучшить)
- [ ] Дашборды (улучшить)
- [x] Навигация (✅ готово)
