import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import {
  login as apiLogin,
  logout as apiLogout,
  verifyToken,
  getAccessToken,
  getCurrentUser,
} from './apiService';

const AuthContext = createContext(null);

// Decode role from JWT token
const getRoleFromToken = () => {
  const token = getAccessToken();
  if (!token) return null;
  try {
    const part = token.split('.')[1];
    if (!part) return null;
    const base64 = part.replace(/-/g, '+').replace(/_/g, '/');
    const padded = base64 + '='.repeat((4 - base64.length % 4) % 4);
    const payload = JSON.parse(atob(padded));
    return payload.role || null;
  } catch {
    return null;
  }
};

export const AuthProvider = ({ children }) => {
  const [accessTokenValid, setAccessTokenValid] = useState(false);
  const [role, setRole] = useState(null); // 'teacher' | 'student' | 'admin'
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);

  const loadUser = useCallback(async () => {
    try {
      const res = await getCurrentUser();
      setUser(res.data);
      if (res.data?.role) {
        setRole(res.data.role);
      }
      return res.data;
    } catch (err) {
      if (err?.response?.status === 401) {
        setAccessTokenValid(false);
        setRole(null);
      }
      console.error('Ошибка загрузки профиля', err);
      setUser(null);
      return null;
    }
  }, []);

  const check = useCallback(async () => {
    const ok = await verifyToken();
    if (ok) {
      setAccessTokenValid(true);
      const userRole = getRoleFromToken();
      setRole(userRole);
      await loadUser();
      setLoading(false);
      return;
    }
    
    // Если access токен невалиден, пытаемся обновить через refresh
    const refreshToken = localStorage.getItem('tp_refresh_token');
    if (refreshToken) {
      try {
        const res = await fetch('http://127.0.0.1:8000/api/jwt/refresh/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ refresh: refreshToken })
        });
        
        if (res.ok) {
          const data = await res.json();
          localStorage.setItem('tp_access_token', data.access);
          setAccessTokenValid(true);
          const userRole = getRoleFromToken();
          setRole(userRole);
          await loadUser();
          setLoading(false);
          return;
        }
      } catch (err) {
        console.error('Не удалось обновить токен:', err);
      }
    }
    
    // Если ничего не помогло - пользователь не авторизован
    setAccessTokenValid(false);
    setRole(null);
    setUser(null);
    setLoading(false);
  }, [loadUser]);

  useEffect(() => { check(); }, [check]);

  const login = useCallback(async ({ email, password, roleSelection }) => {
    await apiLogin(email, password);
    const userRole = getRoleFromToken();
    const resolvedRole = userRole || roleSelection || null;
    setRole(resolvedRole);
    setAccessTokenValid(true);
    await loadUser();
    return resolvedRole;
  }, [loadUser]);

  const logout = useCallback(async () => {
    await apiLogout();
    setAccessTokenValid(false);
    setRole(null);
    setUser(null);
  }, []);

  const refreshUser = useCallback(async () => loadUser(), [loadUser]);

  return (
    <AuthContext.Provider value={{ accessTokenValid, role, loading, user, login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);

export const Protected = ({ allowRoles, children }) => {
  const { accessTokenValid, role, loading } = useAuth();
  if (loading) return <div style={{ padding: '2rem', textAlign: 'center' }}>Проверка авторизации...</div>;
  if (!accessTokenValid) return <div style={{ padding: '2rem', textAlign: 'center' }}>Требуется вход.</div>;
  if (allowRoles && !allowRoles.includes(role)) return <div style={{ padding: '2rem', textAlign: 'center' }}>Недостаточно прав.</div>;
  return children;
};
